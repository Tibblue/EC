drop	table
	packageCLIs
/

drop	synonym
	pc
/

drop	table
	custCLIs
/

drop	synonym
	cc
/

drop	sequence
	ccSeq
/

drop	sequence
	ccSeq0
/

drop	sequence
	ccSeq1
/

drop	sequence
	ccSeq2
/

drop	sequence
	ccSeq3
/

drop	sequence
	ccSeq4
/

drop	sequence
	ccSeq5
/

drop	sequence
	ccSeq6
/

drop	sequence
	ccSeq7
/

drop	sequence
	ccSeq8
/

drop	sequence
	ccSeq9
/

drop	table
	custAccounts
/

drop	synonym
	ca
/

drop	sequence
	caSeq
/

drop	sequence
	caSeq0
/

drop	sequence
	caSeq1
/

drop	sequence
	caSeq2
/

drop	sequence
	caSeq3
/

drop	sequence
	caSeq4
/

drop	sequence
	caSeq5
/

drop	sequence
	caSeq6
/

drop	sequence
	caSeq7
/

drop	sequence
	caSeq8
/

drop	sequence
	caSeq9
/

drop	table
	packageSlots
/

drop	synonym
	ps
/


drop	table
	callPackages
/

drop	synonym
	cp
/

drop	sequence
	cpSeq
/


drop	table
	dialCodes
/

drop	synonym
	dc
/

drop	sequence
	dcSeq
/

drop	table
	custKeys
/

drop	synonym
	ck
/

drop table cc_params
/

