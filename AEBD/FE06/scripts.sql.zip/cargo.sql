insert into CARGO values (1,'Treinador Principal');
insert into CARGO values (2,'Treinador Adjunto');