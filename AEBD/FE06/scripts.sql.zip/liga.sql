insert into LIGA values (1,'Primeira Liga',1800	,1);
insert into LIGA values (2,'II Liga',1810,2);
insert into LIGA values (3,'Campeonato Nacional',1900,2);
