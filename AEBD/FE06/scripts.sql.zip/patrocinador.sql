insert into PATROCINADOR values (1,'NOS',10000);
insert into PATROCINADOR values (2,'MEO',10000);